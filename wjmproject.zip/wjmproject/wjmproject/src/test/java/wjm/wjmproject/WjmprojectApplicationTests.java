package wjm.wjmproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WjmprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
