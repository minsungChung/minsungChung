package wjm.wjmproject.controller;

import org.apache.tomcat.util.json.JSONParser;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class PingController {
    @PostMapping("/intro")
    public String postMethod(@RequestBody String req){
        JSONParser jsonParser = new JSONParser();
        Object obj = jsonParser.parse(req);

        return req.id + "님 환영합니다!";
    }
}
