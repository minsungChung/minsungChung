package wjm.wjmproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import wjm.wjmproject.repository.ResRepository;

import javax.transaction.Transactional;

@Transactional
public class ResService {

    private final ResRepository resRepository;

    @Autowired
    public ResService(ResRepository resRepository) {
        this.resRepository = resRepository;
    }
}
