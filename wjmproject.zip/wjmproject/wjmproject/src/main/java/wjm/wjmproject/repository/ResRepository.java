package wjm.wjmproject.repository;

import wjm.wjmproject.domain.Restaurant;

import java.util.Optional;

public interface ResRepository {
    Optional<Restaurant> findByArea(String area);
}
