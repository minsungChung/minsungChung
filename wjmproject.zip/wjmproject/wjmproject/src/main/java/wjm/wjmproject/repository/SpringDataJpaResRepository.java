package wjm.wjmproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import wjm.wjmproject.domain.Restaurant;

import java.util.Optional;

public interface SpringDataJpaResRepository extends JpaRepository<Restaurant, Long>, ResRepository{
    Optional<Restaurant> findByArea(String area);
}
