package wjm.wjmproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WjmprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(WjmprojectApplication.class, args);
	}

}
