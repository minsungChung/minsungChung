package wjm.wjmproject.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import wjm.wjmproject.repository.JpaResRepository;
import wjm.wjmproject.repository.ResRepository;
import wjm.wjmproject.service.ResService;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

@Configuration
public class SpringConfig {
    private final ResRepository resRepository;

    public SpringConfig(ResRepository resRepository) {
        this.resRepository = resRepository;
    }

    @Bean
    public ResService resService(){
        return new ResService(resRepository);
    }
}
