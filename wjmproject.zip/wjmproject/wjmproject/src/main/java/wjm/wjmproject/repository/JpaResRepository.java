package wjm.wjmproject.repository;

import wjm.wjmproject.domain.Restaurant;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class JpaResRepository implements ResRepository{
    private final EntityManager em;

    public JpaResRepository(EntityManager em) {
        this.em = em;
    }

    public Optional<Restaurant> findByArea(String area) {
        List<Restaurant> result = em.createQuery("select m from Restaurant m where m.area = :area", Restaurant.class)
                .setParameter("area", area)
                .getResultList();
        return result.stream().findAny();
    }

}
