drop table if exists restaurants CASCADE;
create table restaurants
(
    name varchar(255),
    area varchar(25),
    address varchar(255),
    keywords varchar(255),
    primary key (name)
);